import React from 'react';
import Tarea from './Tarea';

class CategoriaTarea extends React.Component {
  render() {
    const { categoria, urgencia, title, completed, onToggleComplete, onDelete } = this.props;
    return (
      <div>
        <h2>Categoria: {categoria}</h2>
        <h4>Urgencia: {urgencia}</h4>
        <Tarea
          title={title}
          completed={completed}
          onToggleComplete={onToggleComplete}
          onDelete={onDelete}
        />
      </div>
    );
  }
}

export default CategoriaTarea;