// src/components/TaskCategory.js
import React from 'react';
import Tarea from './Tarea';

class CategoriaTarea extends Tarea {
  render() {
    return (
      <div>
        <h2>Categoria: {this.props.categoria}</h2>
        {super.render()}
      </div>
    );
  }
}

export default CategoriaTarea;