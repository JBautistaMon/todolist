import React, {useState, useEffect } from 'react';
import '../styles/style.css';

const FechaHora = () => {
    const [fechaHora, setFechaHora] = useState(new Date());
  
    useEffect(() => {
      const intervalo = setInterval(() => {
        setFechaHora(new Date());
      }, 1000);
  
      return () => clearInterval(intervalo);
    }, []);
  
    return (
      <div className="fecha-hora">
        <p>{fechaHora.toLocaleDateString()} {fechaHora.toLocaleTimeString()}</p>
      </div>
    );
  };
  
  export default FechaHora;

  /*useState: Inicializa el estado del componente con la fecha y hora actuales.
    useEffect: Configura un intervalo para actualizar la fecha y hora cada segundo, y limpia el intervalo cuando el componente se desmonta.
    Renderizado: Muestra la fecha y la hora actualizadas en tiempo real en el componente.*/