import React, { useState, useEffect } from 'react';
import CategoriaTarea from './CategoriaTarea';

const categoriasPredefinidas = [
  { id: 1, nombre: 'Programación' },
  { id: 2, nombre: 'Hogar' },
  { id: 3, nombre: 'Trabajo' },
  { id: 4, nombre: 'Salud' },
];

const urgenciasPredefinidas = [
  { id: 1, nombre: 'Baja' },
  { id: 2, nombre: 'Media' },
  { id: 3, nombre: 'Alta' },
];

const ListaTareas = ({ taskManager }) => {
  const [tareaNueva, crearTareaNueva] = useState('');
  const [categoriaSeleccionada, seleccionarCategoria] = useState(categoriasPredefinidas[0].nombre);
  const [urgenciaSeleccionada, seleccionarUrgencia] = useState(urgenciasPredefinidas[0].nombre);
  const [busqueda, setBusqueda] = useState('');
  const [tareasFiltradas, setTareasFiltradas] = useState(taskManager.viewAllTasks());

  useEffect(() => {
    const tareasFiltradas = taskManager.viewAllTasks().filter(tarea =>
      tarea.title.toLowerCase().includes(busqueda.toLowerCase())
    );
    setTareasFiltradas(tareasFiltradas);
  }, [busqueda, taskManager]);

  const añadirTarea = () => {
    if (tareaNueva && categoriaSeleccionada && urgenciaSeleccionada) {
      const nuevaTarea = taskManager.createTask(
        tareaNueva,
        categoriaSeleccionada,
        urgenciaSeleccionada
      );
      console.log('Nueva tarea añadida:', nuevaTarea);
      crearTareaNueva('');
      seleccionarCategoria(categoriasPredefinidas[0].nombre);
      seleccionarUrgencia(urgenciasPredefinidas[0].nombre);
      setTareasFiltradas(taskManager.viewAllTasks());
    }
  };

  const marcarTarea = (tareaId) => {
    taskManager.completeTask(tareaId);
    console.log('Tarea marcada como completada con ID:', tareaId);
    setTareasFiltradas(taskManager.viewAllTasks());
  };

  const eliminarTarea = (tareaId) => {
    taskManager.deleteTask(tareaId);
    console.log('Tarea eliminada con ID:', tareaId);
    setTareasFiltradas(taskManager.viewAllTasks());
  };

  return (
    <div>
      <div>
        <input
          type="text"
          placeholder="Nueva tarea"
          value={tareaNueva}
          onChange={(e) => crearTareaNueva(e.target.value)}
        />
        <select
          value={categoriaSeleccionada}
          onChange={(e) => seleccionarCategoria(e.target.value)}
        >
          {categoriasPredefinidas.map(categoria => (
            <option key={categoria.id} value={categoria.nombre}>
              {categoria.nombre}
            </option>
          ))}
        </select>
        <select
          value={urgenciaSeleccionada}
          onChange={(e) => seleccionarUrgencia(e.target.value)}
        >
          {urgenciasPredefinidas.map(urgencia => (
            <option key={urgencia.id} value={urgencia.nombre}>
              {urgencia.nombre}
            </option>
          ))}
        </select>
        <button onClick={añadirTarea}>Añadir tarea</button>
      </div>
      <input
        type="text"
        placeholder="Buscar tarea"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />
      {tareasFiltradas.map(tarea => (
        <CategoriaTarea
          key={tarea.id}
          title={tarea.title}
          completed={tarea.completed}
          categoria={tarea.categoria}
          urgencia={tarea.urgencia}
          onToggleComplete={() => marcarTarea(tarea.id)}
          onDelete={() => eliminarTarea(tarea.id)}
        />
      ))}
    </div>
  );
};

export default ListaTareas;