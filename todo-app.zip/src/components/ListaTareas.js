// src/components/TaskList.js
import React, { useState } from 'react';
import CategoriaTarea from './CategoriaTarea';

const ListaTareas = () => {
  const [tareas, setTareas] = useState([
    { title: 'Aprender a usar React', completed: false, categoria: 'Programación' },
  ]);

  const [tareaNueva, crearTareaNueva] = useState('');
  const [categoriaNueva, crearCategoriaNueva] = useState('');

  const añadirTarea = () => {
    if (tareaNueva && categoriaNueva) {
      const tareaNuevaObj = {
        id: tareas.length + 1,
        title: tareaNueva,
        completed: false,
        categoria: categoriaNueva,
      };
      setTareas([...tareas, tareaNuevaObj]);
      crearTareaNueva('');
      crearCategoriaNueva('');
    }
  };


  const marcarTarea = (tareaId) => {
    setTareas(tareas.map(tarea => 
      tarea.id === tareaId ? { ...tarea, completed: !tarea.completed } : tarea
    ));
  };

  const eliminarTarea = (tareaId) => {
    setTareas(tareas.filter(tarea => tarea.id !== tareaId));
  };

  return (
    <div>
      <div>
        <input
          type="text"
          placeholder="Nueva tarea"
          value={tareaNueva}
          onChange={(e) => crearTareaNueva(e.target.value)}
        />
        <input
          type="text"
          placeholder="Categoria"
          value={categoriaNueva}
          onChange={(e) => crearCategoriaNueva(e.target.value)}
        />
        <button onClick={añadirTarea}>Añadir tarea</button>
      </div>
      {tareas.map(tarea => (
        <CategoriaTarea
          key={tarea.id}
          title={tarea.title}
          completed={tarea.completed}
          categoria={tarea.categoria}
          onToggleComplete={() => marcarTarea(tarea.id)}
          onDelete={() => eliminarTarea(tarea.id)}
        />
      ))}
    </div>
  );
};
export default ListaTareas;