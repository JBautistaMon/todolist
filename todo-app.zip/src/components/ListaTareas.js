import React, { useState } from 'react';
import CategoriaTarea from './CategoriaTarea';
import TareaCompleta from '../models/TareaCompleta';

const categoriasPredefinidas = [
  { id: 1, nombre: 'Programación' },
  { id: 2, nombre: 'Hogar' },
  { id: 3, nombre: 'Trabajo' },
  { id: 4, nombre: 'Salud' },
  { id: 5, nombre: 'Otros' },
];

const urgenciasPredefinidas = [
  { id: 1, nombre: 'Baja' },
  { id: 2, nombre: 'Media' },
  { id: 3, nombre: 'Alta' },
  { id: 4, nombre: 'MUY ALTA' },
];

const ListaTareas = () => {
  const [tareas, setTareas] = useState([
    new TareaCompleta(1, 'Aprender a usar React', false, 'Programación', 'Media'),
  ]);

  const [tareaNueva, crearTareaNueva] = useState('');
  const [categoriaSeleccionada, seleccionarCategoria] = useState(categoriasPredefinidas[0].nombre); // Con esto definimos que categoria utilizaremos de la array
  const [urgenciaSeleccionada, seleccionarUrgencia] = useState(urgenciasPredefinidas[0].nombre); // Con esto definimos que nivel de urgencia utilizaremos en la array
  const [busqueda, setBusqueda] = useState('');

  const tareasFiltradas = tareas.filter(tarea =>
    tarea.title.toLowerCase().includes(busqueda.toLowerCase())    // function arrow para el filtro para la busqueda de tareas
  );

  const añadirTarea = () => {
    if (tareaNueva && categoriaSeleccionada && urgenciaSeleccionada) {
      const nuevaTarea = new TareaCompleta(
        tareas.length + 1,
        tareaNueva,
        false,
        categoriaSeleccionada,
        urgenciaSeleccionada
      );
      console.log(nuevaTarea)
      setTareas([...tareas, nuevaTarea]);
      crearTareaNueva('');
      seleccionarCategoria(categoriasPredefinidas[0].nombre);
      seleccionarUrgencia(urgenciasPredefinidas[0].nombre);
    }
  };

  const marcarTarea = (tareaId) => {
    setTareas(tareas.map(tarea => 
      tarea.id === tareaId ? { ...tarea, completed: !tarea.completed } : tarea
    ));
  };

  const eliminarTarea = (tareaId) => {
    setTareas(tareas.filter(tarea => tarea.id !== tareaId));
  };

  return (
    <div>
      <div>
        <input
          type="text"
          placeholder="Nueva tarea"
          value={tareaNueva}
          onChange={(e) => crearTareaNueva(e.target.value)}
        />
        <select
          value={categoriaSeleccionada}
          onChange={(e) => seleccionarCategoria(e.target.value)}
        >
          {categoriasPredefinidas.map(categoria => (
            <option key={categoria.id} value={categoria.nombre}>
              {categoria.nombre}
            </option>
          ))}
        </select>
        <select
          value={urgenciaSeleccionada}
          onChange={(e) => seleccionarUrgencia(e.target.value)}
        >
          {urgenciasPredefinidas.map(urgencia => (
            <option key={urgencia.id} value={urgencia.nombre}>
              {urgencia.nombre}
            </option>
          ))}
        </select>
        <button onClick={añadirTarea}>Añadir tarea</button>
      </div>
      <input
        type="text"
        placeholder="Buscar tarea"
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
      />
      {tareasFiltradas.map(tarea => (
        <CategoriaTarea
          key={tarea.id}
          title={tarea.title}
          completed={tarea.completed}
          categoria={tarea.categoria}
          urgencia={tarea.urgencia}
          onToggleComplete={() => marcarTarea(tarea.id)}
          onDelete={() => eliminarTarea(tarea.id)}
        />
      ))}
    </div>
  );
};

export default ListaTareas;