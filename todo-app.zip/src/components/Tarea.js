import React from 'react';

class Tarea extends React.Component {
  render() {
    return (
      <div>
        <h3 style={{ textDecoration: this.props.completed ? 'line-through' : 'none' }}>
          {this.props.title}
        </h3>
        <button onClick={this.props.onToggleComplete}>
          {this.props.completed ? 'Deshacer' : 'Completar'
        }</button>
        <button id="eliminador" onClick={this.props.onDelete}>Eliminar</button>
      </div>
    );
  }
}

export default Tarea;