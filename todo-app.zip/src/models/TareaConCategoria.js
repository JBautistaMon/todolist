
import TareaBase from './TareaBase';

class TareaConCategoria extends TareaBase {
  constructor(id, title, completed, categoria) {
    super(id, title, completed);
    this.categoria = categoria;
  }
}

export default TareaConCategoria;