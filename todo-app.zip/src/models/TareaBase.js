
class TareaBase {
    constructor(id, title, completed = false) {
      this.id = id;
      this.title = title;
      this.completed = completed;
    }
  
    toggleComplete() {
      this.completed = !this.completed;
    }

    update(details){
      this.title = details.title || this.title;
      this.description = details.description || this.description;
      this.dueDate = details.dueDate || this.dueDate;
    }

    

  }
  
  export default TareaBase;