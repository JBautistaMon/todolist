import TaskList from "./TaskList";

class User {
    constructor(id, username, password) {
      this.id = id;
      this.username = username;
      this.password = password;
      this.taskList = new TaskList();
    }
    verifyPassword(password) {
      return this.password === password;
    }
   }
   export default User;