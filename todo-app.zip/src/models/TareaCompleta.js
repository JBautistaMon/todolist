import TareaConCategoria from './TareaConCategoria';

class TareaCompleta extends TareaConCategoria {
  constructor(id, title, completed, categoria, urgencia) {
    super(id, title, completed, categoria);
    this.urgencia = urgencia;
  }
}

export default TareaCompleta;