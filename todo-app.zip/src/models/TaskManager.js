class TaskManager {
    constructor(user) {
      this.user = user;
    }
    createTask(title, description, dueDate) {
      const task = this.user.taskList.addTask(title, description, dueDate);
      console.log('Tarea creada:', task);
      return task;
    }
    deleteTask(id) {
      this.user.taskList.removeTask(id);
      console.log('Tarea eliminada con ID:', id);
    }
    completeTask(id) {
      const task = this.user.taskList.getTaskById(id);
      if (task) {
        task.markAsCompleted();
        console.log('Tarea completada:', task);
      }
    }
    updateTask(id, details) {
      const task = this.user.taskList.getTaskById(id);
      if (task) {
        task.update(details);
        console.log('Tarea actualizada:', task);
      }
    }
    viewAllTasks() {
      console.log('Todas las tareas:', this.user.taskList.getAllTasks());  
      return this.user.taskList.getAllTasks();
    }
    viewPendingTasks() {
      console.log('Tareas pendientes:', this.user.taskList.getPendingTasks()); 
      return this.user.taskList.getPendingTasks();
    }
    viewCompletedTasks() {
        console.log('Tareas completadas:', this.user.taskList.getCompletedTasks());
      return this.user.taskList.getCompletedTasks();
    }
   }

   
   export default TaskManager;