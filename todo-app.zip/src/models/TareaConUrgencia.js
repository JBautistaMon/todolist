import TareaBase from './TareaBase';

class TareaConUrgencia extends TareaBase {
  constructor(id, title, completed, urgencia) {
    super(id, title, completed);
    this.urgencia = urgencia;
  }
}

export default TareaConUrgencia;