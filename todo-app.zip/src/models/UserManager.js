import User from './User';

class UserManager {
 constructor() {
   this.users = [];
   this.loggedInUser = null;
   this.nextUserId = 1;
 }
 addUser(username, password) {
   const user = new User(this.nextUserId++, username, password);
   this.users.push(user);
   return user;
 }
 login(username, password) {
   const user = this.users.find(user => user.username === username);
   if (user && user.verifyPassword(password)) {
     this.loggedInUser = user;
     return user;
   } else {
     throw new Error('Invalid username or password');
   }
 }
 logout() {
   this.loggedInUser = null;
 }
 getLoggedInUser() {
   return this.loggedInUser;
 }
}

export default UserManager;