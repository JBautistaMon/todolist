class Task {
    constructor(id, title, description, dueDate, completed = false) {
      this.id = id;
      this.title = title;
      this.description = description;
      this.dueDate = dueDate;
      this.completed = completed;
    }
    markAsCompleted() {
      this.completed = true;
    }
    update(details) {
      this.title = details.title || this.title;
      this.description = details.description || this.description;
      this.dueDate = details.dueDate || this.dueDate;
    }
    static fromObject(obj) {
      return new Task(obj.id, obj.title, obj.description, obj.dueDate, obj.completed);
    }
    // Getters i setters
    get getTitle() {
      return this.title;
    }
    set setTitle(title) {
      this.title = title;
    }
    get getDescription() {
      return this.description;
    }
    set setDescription(description) {
      this.description = description;
    }
    get getDueDate() {
      return this.dueDate;
    
    }
    get isCompleted() {
      return this.completed;
    }
   }
   export default Task;