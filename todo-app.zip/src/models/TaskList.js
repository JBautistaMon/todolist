import Task from './Task';

class TaskList {
 constructor() {
   this.tasks = [];
   this.nextId = 1;
 }
 addTask(title, description, dueDate) {
   const task = new Task(this.nextId++, title, description, dueDate);
   this.tasks.push(task);
   return task;
 }
 removeTask(id) {
   this.tasks = this.tasks.filter(task => task.id !== id);
 }
 getTaskById(id) {
   return this.tasks.find(task => task.id === id);
 }
 getAllTasks() {
   return this.tasks;
 }
 getPendingTasks() {
   return this.tasks.filter(task => !task.completed);
 }
 getCompletedTasks() {
   return this.tasks.filter(task => task.completed);
 }
 static fromArray(arr) {
   const taskList = new TaskList();
   taskList.tasks = arr.map(Task.fromObject);
   taskList.nextId = taskList.tasks.length ? Math.max(taskList.tasks.map(task => task.id)) + 1 : 1;
   return taskList;
 }
}

export default TaskList;