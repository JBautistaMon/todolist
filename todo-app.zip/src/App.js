// src/App.js
import React from 'react';
import ListaTareas from './components/ListaTareas';
import FechaHora from './components/FechaHora';
import './styles/style.css'
function App() {
  return (
    <div className="App">
      <h1>TAREAS: </h1>
      <ListaTareas/>
      <br></br>
      <FechaHora/>
    </div>
  );
}

export default App;
