import React, { useState } from 'react';
import ListaTareas from './components/ListaTareas';
import UserManager from './models/UserManager';
import TaskManager from './models/TaskManager';
import './styles/style.css';

const userManager = new UserManager();
userManager.addUser('user1', 'password1');
userManager.addUser('user2', 'password2');

const App = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [taskManager, setTaskManager] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleLogin = () => {
    try {
      const user = userManager.login(username, password);
      setCurrentUser(user);
      setTaskManager(new TaskManager(user));
      setLoginError('');
    } catch (error) {
      setLoginError(error.message);
    }
  };

  const handleLogout = () => {
    userManager.logout();
    setCurrentUser(null);
    setTaskManager(null);
  };

  return (
    <div>
      {!currentUser ? (
        <div>
          <h3>Login</h3>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button onClick={handleLogin}>Login</button>
          {loginError && <p style={{ color: 'red' }}>{loginError}</p>}
        </div>
      ) : (
        <div>
          <h2>Bienvenido {currentUser.username}!</h2>
          {taskManager && <ListaTareas taskManager={taskManager} />}
          <br></br><br></br>
          <button onClick={handleLogout}>Salir</button>
        </div>
      )}
    </div>
  );
};

export default App;