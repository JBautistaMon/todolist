El proposit del projecte ha sigut veure una mica el funcionament de les llibreries del node.js / react, familiaritzarnos una mica amb els canvis a temps real i veure els avantatges d'això.

Hem creat un to do - list / una lista de tasques, hem triat un projecte sencill.

En el la lista de tasques tindrem l'opcio de crear més tasques a fer, crearem el objeces amb classes amb el mateix form, seleccionarem la categoria ja estipulada i el nivell d'urgencia de la mateixa.

per executar el projecte hauriem d'executar la comanda: npm install ( per crear els nodes necesaris )
i despres executarem : npm start

ja tendriem la nostra aplicació oberta en localhost:3000


J. Bautista, M. Jimenez, E. Saez